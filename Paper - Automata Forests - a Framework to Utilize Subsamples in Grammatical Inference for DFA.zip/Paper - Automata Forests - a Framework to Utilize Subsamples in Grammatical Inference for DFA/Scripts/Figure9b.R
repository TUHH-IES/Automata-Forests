library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets")

#Filenames for Figure 9b
csv_9b <- file.path(target_folder, "Figure9b.csv")



X1 = read.csv(csv_9b,header=TRUE, dec='.',fill=TRUE)


if(!is.null(X1$noiseratio)){
  X1$noiseratio <- NULL
}


maxscore = X1[1,1]

x1RP = X1[,10]
x1f1 = X1[,11]
x1fed = X1[,12]
x1f3 = X1[,13]
n1 = length(x1RP)


Numbag = X1[,3]
Numbags<-c()
temp = n1/50
for (i in 1:(temp/2)) {
  Numbags[i]= as.numeric(Numbag[i*50])
}


score1rp<-c()
score1f1<-c()
score1fed<-c()
score1f3<-c()
for(i in 1 : n1){
  score1rp[i] = as.numeric(x1RP[i])
  score1f1[i] = as.numeric(x1f1[i])
  score1fed[i] = as.numeric(x1fed[i])
  score1f3[i] = as.numeric(x1f3[i])
}

avg1RP <-c()
avg1F1<-c()
avg1Fed<-c()
avg1F3<-c()


lowl=0
upl=0
lowh=0
uph=0
for(i in 1 : (temp/2)){
  lowl = (i-1)*50+1
  upl =i*50
  lowh = (i-1)*50+1 + (temp/2)
  uph = i*50 + (temp/2)
  avg1RP[i] = mean((c(score1rp[lowl:upl],score1rp[lowh:uph])))
  avg1F1[i] = mean((c(score1f1[lowl:upl],score1f1[lowh:uph])))
  avg1Fed[i] = mean((c(score1fed[lowl:upl],score1fed[lowh:uph])))
  avg1F3[i] = mean((c(score1f3[lowl:upl],score1f3[lowh:uph])))
}

print(Numbags)
print(avg1RP)
print(avg1Fed)


plot(x=Numbags,y=avg1RP,col='black', ylim=c(100,300),xlab = "Bagsize",ylab = "average translated words",type = "l")
lines(x=Numbags,y=avg1F1,type = "l",col='red')
lines(x=Numbags,y=avg1Fed,type = "l",col='blue')
lines(x=Numbags,y=avg1F3,type = "l",col='green')
#legend("topleft", legend=c("RPNI","ForestCV-W","ForestCV-ED", "ForestMV"),
#       col=c("black","red","blue","green"), lty = c(1,1,1,1), cex=1.2)

