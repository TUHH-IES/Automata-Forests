library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets/Alpha Analysis")

#Filenames for 12, 20, and 32 states Target DFA respectively
csv_12 <- file.path(target_folder, "RiseTrainAlpha_States12_SigmaSize2_dataSteps30.csv") #12State Target DFA
csv_20 <- file.path(target_folder, "RiseTrainAlpha_States20_SigmaSize2_dataSteps200.csv") #20State Target DFA
csv_32 <- file.path(target_folder, "RiseTrainAlpha_States32_SimgaSize2_dataSteps100.csv") #32State Target DFA

#For 12 states DFA: 
#The RPNI consistently inferred a hypothesis reaching a score of 987 (on 30 input samples).
#We cannot explain this behaviour as:
#a) due to random merging behavior the hypothesis across 100 repetitions should've been different (but still the same score)
#b) the reached score of accurate classifications drops imediately after adding another 30 samples.
#Due to b) we interpret the results for the RPNI at the initial training data as an outlier not representable for the overall convergence of the RPNI.


#For 32 states DFA:
#the testrun did not continue until convergence, but only until 5000 samples reached.
#The reason for this early stop is the runtime exceeding 1.5 weeks on a local machine, after which we stopped the evaluation, 
#but still wanted to provide the results


x1 = read.csv(csv_20,header=TRUE, dec='.',fill=TRUE)
library(rgl)
library(deldir)

df = data.frame(x1)

ratios <- unique(df$bagratio) #x-axis
dimratio <- length(ratios)

train <- unique(df$posTrainSetSize) + unique(df$negTrainSetSize) #y-achse
dimtrain <- length(train)

postr <- unique(df$posTrainSetSize)
negtr <- unique(df$negTrainSetSize)

avgRP <- c()
avgMV <- c()
avgCV <- c()
leng = length(df$maxScore)
zSize=leng/100
for(i in 1:zSize){
  low = (i-1)*100+1
  up =i*100
  #mean
  avgRP[i] <- mean(df$RPNIScore[low:up])
  avgMV[i] <- mean(df$ForestMVScore[low:up])
  avgCV[i] <- mean(df$ForestCVScore[low:up])
}


xli <- c(0,1) #x-axis
yli <- c(0,train) #y-axis
zli <- c(0,1000) #z-axis


persp3d(ratios,train,avgRP, col = 'grey', front = "lines", back = "lines",xlab = expression(alpha), ylab = "train. set", zlab = "score")
surface3d(ratios,train,avgMV,color = "green")


persp3d(ratios,train,avgRP, col = 'grey', front = "lines", back = "lines",xlab = expression(alpha), ylab = "train. set", zlab = "score")
surface3d(ratios,train,avgCV,color = "red")

maxVMV <-c()
maxVCV <-c()
maxVRP <-c()
maxRMV <-c()
maxRCV <-c()
for(i in 1:dimtrain){
  low = (i-1)*dimratio+1
  up =i*dimratio
  maxVMV[i] <- max(avgMV[low:up])
  maxVCV[i] <- max(avgCV[low:up])
  maxVRP[i] <- max(avgRP[low:up])
  index = which.max(avgMV[low:up])
  maxRMV[i] <- df$bagratio[index*100]
  index = which.max(avgCV[low:up])
  maxRCV[i] <- df$bagratio[index*100]
}
print(maxVMV)
print(maxVCV)
print(maxRMV)
print(maxRCV)

print(median(maxRMV))
print(median(maxRCV))
print(mean(maxRMV))
print(mean(maxRCV))


x <- c(1:dimtrain)
for (i in 1:dimtrain) {
  x[i] <- x[i]*200
}



plot(x,maxVMV,col='green', ylim=c(500,1000),xlab = "size of training data",ylab = "maximal translated words",type = "l")
lines(x,maxVCV,type = "l",col='red')
lines(x,maxVRP,type = "l",col='black')
legend("bottomright", legend=c("RPNI","ForestCV","ForestMV"),
       col=c("black","red","green"), lty = c(1,1,1), cex=1.8)


plot(x,maxRMV,col='green', ylim=c(0.0,1),xlab = "size of training data",ylab = expression(alpha ~ "yielding maximal value"),type = "l")
lines(x,maxRCV,type = "l",col='red')

