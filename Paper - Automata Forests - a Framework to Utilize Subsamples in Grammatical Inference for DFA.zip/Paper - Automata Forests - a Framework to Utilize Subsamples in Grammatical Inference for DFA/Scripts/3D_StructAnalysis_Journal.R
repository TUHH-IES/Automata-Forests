library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets/Structural Analysis")

#Filenames for 12, 20, and 32 states Target DFA respectively
csv_12 <- file.path(target_folder, "RiseTrainAlphaStruct_12States_2sigma.csv") #12State Target DFA
csv_20 <- file.path(target_folder, "RiseTrainAlphaStruct_20States_2sigma.csv") #20State Target DFA
csv_32 <- file.path(target_folder, "RiseTrainAlphaStruct_32States_2sigma.csv") #32State Target DFA


x1 = read.csv(csv_32,header=TRUE, dec='.',fill=TRUE)
library(rgl)
library(deldir)
library(scatterplot3d)

df = data.frame(x1)

train <- unique(df$trainSet) #x-axis

column_name <- "ForestInd0States"
indStartS <- which(names(df) == column_name)[1]
column_name <- paste(c("ForestInd",df$numbags[1]-1,"States"),collapse = "")
indEndS <- which(names(df) == column_name)[1]
columns_to_analyze <- c(indStartS:indEndS)  # Replace with the desired column indices
# Find the minimum values for the specified columns
min_values <- apply(df[, columns_to_analyze], 2, min)
# Find the maximum values for the specified columns
max_values <- apply(df[, columns_to_analyze], 2, max)
states <- c(0,max(max_values)+10) #y-axis


column_name <- "ForestInd0Depth"
indStartD <- which(names(df) == column_name)[1]
column_name <- paste(c("ForestInd",df$numbags[1]-1,"Depth"),collapse = "")
indEndD <- which(names(df) == column_name)[1]
columns_to_analyze <- c(indStartD:indEndD)  # Replace with the desired column indices
# Find the minimum values for the specified columns
min_values <- apply(df[, columns_to_analyze], 2, min)
# Find the maximum values for the specified columns
max_values <- apply(df[, columns_to_analyze], 2, max)
depth <- c(0,max(max_values)+10) #y-axis

cvStates <- c()
cvDepth <- c()
for (i in 1:length(train)) {
  pos <- df$CV.Pos[i]
  column_nameCVS <- paste(c("ForestInd",pos,"States"),collapse = "")
  cvStates[i] <- df[[column_nameCVS]][i]
  column_nameCVD <- paste(c("ForestInd",pos,"Depth"),collapse = "")
  cvDepth[i] <- df[[column_nameCVD]][i]
}

myColorRamp <- function(colors, values) {
  v <- (values - min(values))/diff(range(values))
  x <- colorRamp(colors)(v)
  rgb(x[,1], x[,2], x[,3], maxColorValue = 255)
}

column_name <- "ForestInd0ActivationPerc"
indStartF <- which(names(df) == column_name)[1]
column_name <- paste(c("ForestInd",df$numbags[1]-1,"ActivationPerc"),collapse = "")
indEndF <- which(names(df) == column_name)[1]
feature <- data.matrix(df[indStartF:indEndF])
cols <- myColorRamp(c("blue", "red"), feature) 

maxs <- max(max(df$RPNIStateSize),max(cvStates),max(df$targetStates))
maxd <- max(max(df$RPNIDepth),max(cvDepth),max(df$targetDepth))
maxt <- train[length(train)-1]
mins <- min(min(df$RPNIStateSize),min(cvStates),min(df$targetStates))
mind <- min(min(df$RPNIDepth),min(cvDepth),min(df$targetDepth))
mint <- train[1]



xdim <- c(mint,maxt)
ydim <- c(0,maxs)
zdim <- c(0,maxd)

plot3d(train, data.matrix(df[indStartS:indEndS]), data.matrix(df[indStartD:indEndD]), xlim = xdim, ylim = ydim, zlim = zdim,xlab = "trainset", ylab = "states", zlab = "depth",col = cols, plot = "p")




plot3d(x = NA, y = NA, z = NA, xlim = xdim, ylim = ydim, zlim = zdim, type = "n",xlab = "trainset", ylab = "states", zlab = "depth")
lines3d(train, df$targetStates, z = df$targetDepth, col = "black",add = T)  
points3d(train, df$RPNIStateSize, z = df$RPNIDepth, col = "darkgrey", add = T)
points3d(train, cvStates, z = cvDepth, col = "darkolivegreen", add = T)

dist <- function(p1,p2,q1,q2) {
  result <- sqrt((p1-q1)^2 + (p2-q2)^2)
  return(result)
}



avgDist <- function(targetS,targetD,colS,colD){
  result <- 0
  for(i in 1:length(colS)){
    result = result + dist(targetS,targetD,colS[i],colD[i])
  }
  result = result/length(colS)
  return(result)
}

varDist <- function(targetS,targetD,colS,colD){
  vec <- c()
  for(i in 1:length(colS)){
    vec[i] = dist(targetS,targetD,colS[i],colD[i])
  }
  result = var(vec)
  return(result)
}


print(avgDist(df$targetStates[1],df$targetDepth[1],df$RPNIStateSize,df$RPNIDepth))
print(avgDist(df$targetStates[1],df$targetDepth[1],cvStates,cvDepth))

print(varDist(df$targetStates[1],df$targetDepth[1],df$RPNIStateSize,df$RPNIDepth))
print(varDist(df$targetStates[1],df$targetDepth[1],cvStates,cvDepth))




legend_image <- as.raster(matrix(sort(cols, decreasing = TRUE), ncol=1))
plot(c(0,2),c(0,1),type = 'n', axes = F,xlab = '', ylab = '', main = 'activation percentage of automata')
text(x=1.5, y = seq(0,1,l=5), labels = c(0.54,0.65,0.76,0.87,0.975), cex = 2.3)
rasterImage(legend_image, 0, 0, 1,1)








