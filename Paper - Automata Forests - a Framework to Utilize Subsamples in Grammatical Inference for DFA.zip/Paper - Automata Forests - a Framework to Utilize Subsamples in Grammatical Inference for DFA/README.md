# Datasets - Automata Forests: a Framework to Utilize Subsamples in Grammatical Inference for DFA

This folder contains data and R scripts used in the conference paper "Automata Forests: a Framework to Utilize Subsamples in Grammatical Inference for DFA".

Within the folder "Data" the datasets for each figure are presented, as well as a ".txt" file explaining how to reproduce the files.
Using the ".jar" executable in the parent directory, the corresponding datasets can be reproduced and validated.

The folder "R scripts" presents the corresponding scripts to produce each figure.

Each number corresponds to the respective figure number.
To switch between the subfigures (a to c) please change between the accessed files within the R scripts of each figure.

Figures already present in the paper "Using Forest Structures for Passive Automata Learning" are duplicted with the corresponding R scripts.

## Structure and Alpha Analysis

We provided seperate folders for 3D-figures in Section 5.4 and 6.1.
They contain randomly generated target DFAs for 12, 20, and 32 states.

Regarding 12 state DFA: an anomaly is occuring at the initial step with regards to the achieved score of correctly classified words (near perfect classification of the RPNI hypothesis).
We view this step as an anomaly, as the reached classification score is not inline with the respective convergence behavior of the RPNI.
Additionally, typically the provided and implemented algorithm for the RPNI (as provided by LearnLib), when repeating inference mostly provides different hypotheses for equal training sets (due to inner randomization).
In terms of reached score, this behavior is not occuring at the initial step within the alpha analysis, which is why we omit the interpretation of the initial step and view it as an outlier.
Beyond the initial step, we interpret the results as valid.

Regarding 32 state DFA: due to the increasingly long inference time and no sign of imminent convergence we ended the inference after reaching 5000 samples.
Therefore the provided results are incomplete for the provided example, as the RPNI algorithm is not converged.
Nonetheless, the obtained results follow the inference technique of automata forests.

Results of the 32 state DFA can be continued (if the need arises) by setting the starting samplesize as the last provided samplesize (currently ~5000).
Calculated results can then be manually copied into the provided ".csv" file.
Still, it is possible that, given the current seeding to generate words, the RPNI is not converging before 10.000-100.000 training samples.
Therefore, continuing the inference may not provide useful insights into the inference behavior of the respective algorithms.
The current results were obtained by running the experiment for approximately 1.5 weeks (~270 hours) on a local machine.
