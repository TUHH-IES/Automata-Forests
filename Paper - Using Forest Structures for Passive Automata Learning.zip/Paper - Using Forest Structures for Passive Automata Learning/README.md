# Datasets - Using Forest Structures for Passive Automata Learning

Within the folder "Data" the datasets for each figure are presented, as well as a ".txt" file explaining how to reproduce the files.
Using the ".jar" executable in the parent directory, the corresponding datasets can be reproduced and validated.

## Getting Started

The folder "R scripts" presents the corresponding scripts to produce each figure.

Each number corresponds to the respective figure number.
To switch between the subfigures (a to c) please change between the accessed files within the R scripts of each figure.
