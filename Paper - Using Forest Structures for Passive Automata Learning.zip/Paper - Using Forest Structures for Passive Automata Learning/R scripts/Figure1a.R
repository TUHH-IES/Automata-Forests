library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets")

#Filenames for Figure 1 a, b, and c
csv_1a <- file.path(target_folder, "Figure1a.csv")
csv_1b <- file.path(target_folder, "Figure1b.csv")
csv_1c <- file.path(target_folder, "Figure1c.csv")


x1 = read.csv(csv_1a,header=TRUE, dec='.',fill=TRUE)

X1 = x1[order(x1$bagratio),]


maxscore = X1[1,1]
x1RP = X1[,7]
x1f1 = X1[,8]
x1f3 = X1[,9]
n1 = length(x1RP)

bagRatio = X1[,2]
bagratio<-c()

temp = n1/(600)

for (i in 1:temp) {
  bagratio[i]= as.numeric(bagRatio[i*600])
}
print(bagratio)

score1rp<-c()
score1f1<-c()
score1f3<-c()
for(i in 1 : n1){
  score1rp[i] = as.numeric(x1RP[i])
  score1f1[i] = as.numeric(x1f1[i])
  score1f3[i] = as.numeric(x1f3[i])
}

avg1RP <-c()
avg1F1<-c()
avg1F3<-c()

low= 0
up = 0
for (i in 1:temp) {
  low = (i-1)*600+1
  up =i*600
  avg1RP[i] = mean(score1rp[low:up])
  avg1F1[i] = mean((c(score1f1[low:up])))
  avg1F3[i] = mean((c(score1f3[low:up])))
}


plot(x=bagratio,y=avg1RP,col='black', ylim=c(880,1050),xlab = "Bagsize",ylab = "average translated words",type = "l")
lines(x=bagratio,y=avg1F1,type = "l",col='red')
lines(x=bagratio,y=avg1F3,type = "l",col='green')
legend("topleft", legend=c("RPNI","ForestCV","ForestMV"),
       col=c("grey","red","green"), lty = c(1,1,1), cex=1.4)
