library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets")

#Filenames for Figure 1b and c
csv_1b <- file.path(target_folder, "Figure1b.csv")
csv_1c <- file.path(target_folder, "Figure1c.csv")

#change between the figures here, by exchanging the filename:
csv_file <- csv_1b
x1 = read.csv(csv_file,header=TRUE, dec='.',fill=TRUE)

#to change between files, also modify the name given towards the if block:
rang <- 0
if(basename(csv_file)=="Figure1b.csv"){
  rang <-600
}else{
  rang <-100
}

X1 = x1[order(x1$bagratio),]


maxscore = X1[1,1]
x1RP = X1[,10]
x1f1 = X1[,11]
x1fed = X1[,12]
x1f3 = X1[,13]
n1 = length(x1RP)

bagRatio = X1[,2]
bagratio<-c()



temp = n1/(rang)

for (i in 1:temp) {
  bagratio[i]= as.numeric(bagRatio[i*rang])
}
print(bagratio)

score1rp<-c()
score1f1<-c()
score1fed<-c()
score1f3<-c()
for(i in 1 : n1){
  score1rp[i] = as.numeric(x1RP[i])
  score1f1[i] = as.numeric(x1f1[i])
  score1fed[i] = as.numeric(x1fed[i])
  score1f3[i] = as.numeric(x1f3[i])
}

avg1RP <-c()
avg1F1<-c()
avg1Fed<-c()
avg1F3<-c()

low= 0
up = 0
for (i in 1:temp) {
  low = (i-1)*rang+1
  up =i*rang
  avg1RP[i] = mean(score1rp[low:up])
  avg1F1[i] = mean((c(score1f1[low:up])))
  avg1Fed[i] = mean((c(score1fed[low:up])))
  avg1F3[i] = mean((c(score1f3[low:up])))
}



plot(x=bagratio,y=avg1RP,col='black', ylim=c(0,450),xlab = expression(alpha),ylab = "average translated words",type = "l")
lines(x=bagratio,y=avg1F1,type = "l",col='red')
lines(x=bagratio,y=avg1Fed,type = "l",col='blue')
lines(x=bagratio,y=avg1F3,type = "l",col='green')
legend("topleft", legend=c("RPNI","ForestCV-W","ForestCV-ED", "ForestMV"),
       col=c("black","red","blue","green"), lty = c(1,1,1,1), cex=1.2)

