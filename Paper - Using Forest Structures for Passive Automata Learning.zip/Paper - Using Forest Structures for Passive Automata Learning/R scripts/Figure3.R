library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets")

#Filenames for Figure 3 a and b
csv_3a <- file.path(target_folder, "Figure3a.csv")
csv_3b <- file.path(target_folder, "Figure3b.csv")


X1 = read.csv(csv_3a,header=TRUE, dec='.',fill=TRUE)


maxscore = X1[1,1]

xRP = X1[,7]
xf1 = X1[,8]
xf3 = X1[,9]
n1 = length(xRP)

fposRP= X1[,10]
fposF1=X1[,11]
fposF3=X1[,12]
fnegRP=X1[,13]
fnegF1=X1[,14]
fnegF3=X1[,15]

etRP=X1$compTimeRPNI
etF1=X1$compTimeFCV
etF3=X1$compTimeFMV

score1rp<-c()
score1f1<-c()
score1f3<-c()
fprp<-c()
fpf1<-c()
fpf3<-c()
fnrp<-c()
fnf1<-c()
fnf3<-c()
trp<-c()
tf1<-c()
tf3<-c()
for(i in 1 : n1){
  score1rp[i] = as.numeric(xRP[i])
  score1f1[i] = as.numeric(xf1[i])
  score1f3[i] = as.numeric(xf3[i])
  fprp[i] = as.numeric(fposRP[i])
  fpf1[i] = as.numeric(fposF1[i])
  fpf3[i] = as.numeric(fposF3[i])
  fnrp[i] = as.numeric(fnegRP[i])
  fnf1[i] = as.numeric(fnegF1[i])
  fnf3[i] = as.numeric(fnegF3[i])
  trp[i] = as.numeric(etRP[i])
  tf1[i] = as.numeric(etF1[i])
  tf3[i] = as.numeric(etF3[i])
}

maxfromvec <- function(vec1,vec2,vec3){
  ret <- c()
  ret[1] = max(vec1)
  ret[2] = max(vec2)
  ret[3] = max(vec3)
  return(max(ret))
}

minfromvec <- function(vec1,vec2,vec3){
  ret <- c()
  ret[1] = min(vec1)
  ret[2] = min(vec2)
  ret[3] = min(vec3)
  return(min(ret))
}

perincr <- function(num1,num2){
  dif = num2-num1
  return(dif/num1*100)
}

avg1rp = mean(score1rp)
avg1f1 = mean(score1f1)
avg1f3 = mean(score1f3)

cat(avg1rp,avg1f1,avg1f3,"\n")
cat(perincr(avg1rp,avg1f1),perincr(avg1rp,avg1f3),"\n")
print("\n")
var1rp= var(score1rp)
var1f1= var(score1f1)
var1f3= var(score1f3)

cat(var1rp,var1f1,var1f3,"\n")
cat(perincr(var1rp,var1f1),perincr(var1rp,var1f3),"\n")
print("\n")
avfprp = mean(fprp)
avfpf1 = mean(fpf1)
avfpf3 = mean(fpf3)

cat(avfprp,avfpf1,avfpf3,"\n")
cat(perincr(avfprp,avfpf1),perincr(avfprp,avfpf3),"\n")
print("\n")
avfnrp = mean(fnrp)
avfnf1 = mean(fnf1)
avfnf3 = mean(fnf3)

cat(avfnrp,avfnf1,avfnf3,"\n")
cat(perincr(avfnrp,avfnf1),perincr(avfnrp,avfnf3),"\n")
print("\n")
avgtrp = mean(trp)
avgtf1 = mean(tf1)
avgtf3 = mean(tf3)
cat(avgtrp,avgtf1,avgtf3,"\n")
cat(perincr(avgtrp,avgtf1),perincr(avgtrp,avgtf3),"\n")




xlim1max = maxfromvec(score1rp,score1f1,score1f3)
xlim1min = minfromvec(score1rp,score1f1,score1f3)
hist(score1rp,freq = F, xlim = c(xlim1min,xlim1max), ylim=c(0,0.2), main=NULL,xlab = "number of correct classified words", ylab = "density")
legend("topleft", legend=c("RPNI","ForestCV","ForestMV"),
       col=c("grey","red","green"), lty = c(1,1,1), cex=1.4)
hist(score1f1,col = rgb(1,0,0,1/4),add =TRUE,freq = FALSE)
hist(score1f3,col = rgb(0,1,0,1/4),add =TRUE,freq = FALSE)

