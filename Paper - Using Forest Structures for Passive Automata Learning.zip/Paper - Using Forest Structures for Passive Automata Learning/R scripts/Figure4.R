library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets")

#Filenames for Figure 4 a, b, and c
csv_4a <- file.path(target_folder, "Figure4a.csv")
csv_4b <- file.path(target_folder, "Figure4b.csv")
csv_4c <- file.path(target_folder, "Figure4c.csv")


X1 = read.csv(csv_4a,header=TRUE, dec='.',fill=TRUE)

maxscore = X1[1,1]

x1RPS = X1[,10]
x1f1S = X1[,11]
x1fedS = X1[,12]
x1f3S = X1[,13]
n1 = length(x1RPS)

x1RPE = X1[,14]
x1f1E = X1[,15]
x1fedE = X1[,16]
x1f3E = X1[,17]

x1RPL = X1[,18]
x1f1L = X1[,19]
x1fedL = X1[,20]
x1f3L = X1[,21]

x1trp = X1[,22]
x1tf1 = X1[,23]
x1tfed = X1[,24]
x1tf3 = X1[,25]

score1rps<-c()
score1f1s<-c()
score1feds<-c()
score1f3s<-c()

score1rpe<-c()
score1f1e<-c()
score1fede<-c()
score1f3e<-c()

score1rpl<-c()
score1f1l<-c()
score1fedl<-c()
score1f3l<-c()

trp<-c()
tf1<-c()
tfe<-c()
tf3<-c()

for(i in 1 : n1){
  score1rps[i] = as.numeric(x1RPS[i])
  score1f1s[i] = as.numeric(x1f1S[i])
  score1feds[i] = as.numeric(x1fedS[i])
  score1f3s[i] = as.numeric(x1f3S[i])
  
  score1rpe[i] = as.numeric(x1RPE[i])
  score1f1e[i] = as.numeric(x1f1E[i])
  score1fede[i] = as.numeric(x1fedE[i])
  score1f3e[i] = as.numeric(x1f3E[i])
  
  score1rpl[i] = as.numeric(x1RPL[i])
  score1f1l[i] = as.numeric(x1f1L[i])
  score1fedl[i] = as.numeric(x1fedL[i])
  score1f3l[i] = as.numeric(x1f3L[i])
  
  trp[i] = as.numeric(x1trp[i])
  tf1[i] = as.numeric(x1tf1[i])
  tfe[i] = as.numeric(x1tfed[i])
  tf3[i] = as.numeric(x1tf3[i])
}

for(i in 1 : n1){
  if(score1rps[i] > score1rpl[i]){
    print(i)
    print("rp")
  }
  if(score1f1s[i] > score1f1l[i]){
    print(i)
    print("f1")
  }
  if(score1feds[i] > score1fedl[i]){
    print(i)
    print("fed")
  }
  if(score1f3s[i] > score1f3l[i]){
    print(i)
    print("f3")
  }
}

maxfromvec <- function(vec1,vec2,vec3){
  ret <- c()
  ret[1] = max(vec1)
  ret[2] = max(vec2)
  ret[3] = max(vec3)
  return(max(ret))
}

minfromvec <- function(vec1,vec2,vec3){
  ret <- c()
  ret[1] = min(vec1)
  ret[2] = min(vec2)
  ret[3] = min(vec3)
  return(min(ret))
}

perincr <- function(num1,num2){
  dif = num2-num1
  return(dif/num1*100)
}

avg1rps = mean(score1rps)
avg1f1s = mean(score1f1s)
avg1feds = mean(score1feds)
avg1f3s = mean(score1f3s)

cat(avg1rps,avg1f1s,avg1feds,avg1f3s,"\n")
cat(perincr(avg1rps,avg1f1s),perincr(avg1rps,avg1feds),perincr(avg1rps,avg1f3s),"\n")

var1rps= var(score1rps)
var1f1s= var(score1f1s)
var1feds = var(score1feds)
var1f3s= var(score1f3s)

cat(var1rps,var1f1s,var1feds,var1f3s,"\n")
cat(perincr(var1rps,var1f1s),perincr(var1rps,var1feds),perincr(var1rps,var1f3s),"\n")
atrp = mean(trp)
atf1 = mean(tf1)
atfe = mean(tfe)
atf3 = mean(tf3)

cat(atrp,atf1,atfe,atf3,"\n")
cat(perincr(atrp,atf1),perincr(atrp,atfe),perincr(atrp,atf3),"\n")


xlimsmax = maxfromvec(score1rps,score1f1s,score1f3s)
xlimsmin = minfromvec(score1rps,score1f1s,score1f3s)

xlimemax = maxfromvec(score1rpe,score1f1e,score1f3e)
xlimemin = minfromvec(score1rpe,score1f1e,score1f3e)

xlimlmax = maxfromvec(score1rpl,score1f1l,score1f3l)
xlimlmin = minfromvec(score1rpl,score1f1l,score1f3l)



hist(score1rps,freq = F, xlim = c(xlimsmin-10,xlimsmax+10),main=NULL,ylim=c(0,0.03),xlab = "correct translated words", ylab = "density")
#legend("topleft", legend=c("RPNI","ForestCV-W","ForestCV-ED", "ForestMV"),
#       col=c("black","red","blue","green"), lty = c(1,1,1,1), cex=1.2)
hist(score1f1s,col = rgb(1,0,0,1/4),add =TRUE,freq = FALSE)
hist(score1feds,col = rgb(0,0,1,1/4),add =TRUE,freq = FALSE)
hist(score1f3s,col = rgb(0,1,0,1/4),add =TRUE,freq = FALSE)



