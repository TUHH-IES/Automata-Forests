library(rstudioapi)

#get the directory of the currently running script
script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
parent_dir <- dirname(script_dir)
target_folder <- file.path(parent_dir, "Datasets")

#Filenames for Figure 2a
csv_2a <- file.path(target_folder, "Figure2a.csv")



x1 = read.csv(csv_2a,header=TRUE, dec='.',fill=TRUE)

X1 = x1[order(x1$numbags),]


maxscore = X1[1,1]
x1RP = X1[,7]
x1f1 = X1[,8]
x1f3 = X1[,9]
n1 = length(x1RP)

Numbag = X1[,3]
Numbags<-c()

temp = n1/(300)

for (i in 1:temp) {
  Numbags[i]= as.numeric(Numbag[i*300])
}


score1rp<-c()
score1f1<-c()
score1f3<-c()
for(i in 1 : n1){
  score1rp[i] = as.numeric(x1RP[i])
  score1f1[i] = as.numeric(x1f1[i])
  score1f3[i] = as.numeric(x1f3[i])
}

avg1RP <-c()
avg1F1<-c()
avg1F3<-c()

low= 0
up = 0
for (i in 1:temp) {
  low = (i-1)*300+1
  up =i*300
  avg1RP[i] = mean(score1rp[low:up])
  avg1F1[i] = mean((c(score1f1[low:up])))
  avg1F3[i] = mean((c(score1f3[low:up])))
}


plot(x=Numbags,y=avg1RP,col='black', ylim=c(950,1030),xlab = "Bagsize",ylab = "average translated words",type = "l")
lines(x=Numbags,y=avg1F1,type = "l",col='red')
lines(x=Numbags,y=avg1F3,type = "l",col='green')
legend("topleft", legend=c("RPNI","ForestCV","ForestMV"),
       col=c("grey","red","green"), lty = c(1,1,1), cex=1.4)

print(avg1RP)
print(avg1F1)
print(avg1F3)


